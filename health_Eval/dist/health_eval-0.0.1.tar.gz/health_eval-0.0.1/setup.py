# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['health_eval']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'health-eval',
    'version': '0.0.1',
    'description': 'A unified health evaluation parameter',
    'long_description': '',
    'author': 'Nandish Shah',
    'author_email': 'na2465@srmist.edu.in',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/NANDISHSHAH/Health_Eval',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
